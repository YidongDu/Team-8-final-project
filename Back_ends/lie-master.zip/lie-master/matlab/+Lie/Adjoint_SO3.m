function [ Ad ] = Adjoint_SO3( X )
%ADJOINT_SO3 Computes the adjoint of SO(3)
Ad = X;
end

