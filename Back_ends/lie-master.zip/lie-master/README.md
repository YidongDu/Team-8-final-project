# lie
Contains a number of useful functions for dealing with Lie groups
